// This file should import both data files and export them as shown in the lecture code
import movieDataFunctions from './movies.js';

export const moviesData = movieDataFunctions;