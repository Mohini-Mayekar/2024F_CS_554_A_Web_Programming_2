export const apiConfig = {
    apiKey: import.meta.env.VITE_TICKET_MASTER_API_KEY,
    baseUrl: import.meta.env.VITE_BASE_URL
};